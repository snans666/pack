def Hello() :
    print("Hello")
